# AuraHealth Nexus RAG Capstone

A from-scratch Retrieval-Augmented Generation system built for the fictional
"AuraHealth Nexus" document set.

## Architecture

```
Data/*.txt --> loader.py --> chunker.py --> vectorstore.py --> [FAISS index]
                                                                     |
                                       user query --> retrieval (top-k) --> generator.py (Groq + Llama) --> answer
```

| Stage       | File              | Approach |
|-------------|-------------------|----------|
| Loading     | `loader.py`       | Reads every `.txt` in `data/`, normalizes line endings |
| Chunking    | `chunker.py`      | Paragraph-aware greedy packing, ~900 chars/chunk, 150-char overlap, hard-splits any oversized paragraph |
| Embedding   | `vectorstore.py`  | TF-IDF (1-2 gram, scikit-learn) — see note below |
| Vector DB   | `vectorstore.py`  | FAISS `IndexFlatIP` (cosine similarity via L2-normalized vectors) |
| Retrieval   | `vectorstore.py` `.search()` | Top-k nearest chunks by cosine similarity |
| Generation  | `generator.py`    | Groq + Llama (`llama-2-13b` by default), strict "context-only" system prompt |
| Memory      | `rag_pipeline.py` | Bonus: follow-up questions are rewritten into standalone questions using chat history before retrieval |

### Why TF-IDF instead of a neural embedding model?
The task suggests options like OpenAI `text-embedding-3-small` or HuggingFace
`all-MiniLM-L6-v2`. This environment's sandbox network only allows a
whitelisted set of package-index domains (npm/pypi/etc.) and cannot reach
`huggingface.co` or `api.openai.com`, so downloading a pretrained neural
embedding model isn't possible here. TF-IDF is a legitimate, fully offline
embedding technique, and it works particularly well on this corpus because
the evaluation questions hinge on exact keywords/entities (codes, drug
names, percentages, room numbers) that TF-IDF weights strongly.

**To swap in a neural embedding model** (recommended if you run this outside
a network-restricted sandbox), only `vectorstore.py` needs to change:
replace the `TfidfVectorizer` fit/transform calls with calls to
`sentence-transformers` (`all-MiniLM-L6-v2`) or the OpenAI/Anthropic
embeddings API — the FAISS storage, retrieval, and generation code is
embedding-agnostic.

## Setup

```bash
pip install -r requirements.txt
export GROQ_API_KEY="your-key-here"
export GROQ_MODEL="llama-2-13b"
```

## Usage

Interactive CLI chat (build/loads the index automatically, supports
follow-up questions via conversational memory):

```bash
python3 rag_pipeline.py
```

Run all 30 required evaluation questions from `Task.md`:

```bash
python3 evaluate.py
```

Rebuild the index from scratch (e.g. after editing chunk size):

```python
from rag_pipeline import RAGPipeline
p = RAGPipeline()
p.index(force_rebuild=True)
```

## Verifying retrieval without an API key

You don't need `GROQ_API_KEY` to test the retrieval half of the
pipeline (loading, chunking, embedding, vector search). For example:

```python
from rag_pipeline import RAGPipeline
p = RAGPipeline()
p.index()
for chunk, score in p.store.search("What is the override code for the Cognitive Reset Sequence?", top_k=3):
    print(score, chunk.source, chunk.text[:150])
```

This was run for all 30 questions during development and each one's
top result correctly comes from the document that contains the answer
(e.g. Q4 -> `AuraHealth_Employee_Handbook_2026.txt`, Q9 -> `Quantum_MRI_Operation_Manual.txt`,
Q30 -> `Extraterrestrial_Pathogen_Handling.txt`).

## Bonus: Conversational Memory

`RAGPipeline.ask()` keeps a running chat history. For a follow-up like:

```
You: What are the symptoms of Phase 2 of NeuroCrystal Syndrome?
Assistant: ...
You: And what is the treatment for it?
```

the pipeline first calls `Generator.contextualize_query()`, which uses
Groq + the chat history to rewrite "And what is the treatment for it?"
into a standalone query (e.g. "What is the treatment for Phase 2 of
NeuroCrystal Syndrome?") *before* running retrieval. This fixes the
classic conversational-RAG failure mode where a pronoun-only follow-up
retrieves nothing relevant. The original (non-rewritten) question is
still what's sent to the final answer-generation call, along with the
full chat history, so responses stay natural.

## File Guide

- `loader.py` — Requirement 1 (Document Loading)
- `chunker.py` — Requirement 2 (Chunking)
- `vectorstore.py` — Requirements 3 & 4 (Embedding + Vector Database)
- `vectorstore.py::search()` — Requirement 5 (Retrieval)
- `generator.py` — Requirement 6 (Generation, context-only prompt)
- `rag_pipeline.py` — orchestrates everything + Bonus (conversational memory)
- `evaluate.py` — runs the 30 required evaluation questions
- `data/` — the 10 provided source documents
