# 🤖 LLM Fundamentals & APIs — Practical Assignment

![Python](https://img.shields.io/badge/Python-3.10%2B-blue?logo=python&logoColor=white)
![Groq](https://img.shields.io/badge/Groq-Free%20Tier-orange)
![Gemini](https://img.shields.io/badge/Gemini-Free%20Tier-4285F4?logo=google)
![Status](https://img.shields.io/badge/Status-Complete-brightgreen)

**CodeTrade.io — Practical Assignment: LLM Fundamentals & APIs**

This project implements all 4 required tasks using **two genuinely free LLM APIs**:

| Provider | Free Tier? | Sign-up | Notes |
|---|---|---|---|
| **Groq** | ✅ Yes, no credit card | https://console.groq.com/keys | Extremely fast (Llama 3.1 8B Instant) |
| **Google Gemini** | ✅ Yes, generous limits | https://aistudio.google.com/app/apikey | gemini-1.5-flash model |

---

## ⚡ Quick Start — Run Without Any API Keys (Mock Mode)

**Every script in this project runs immediately, with zero setup**, using a built-in
**Mock Mode**. If `GROQ_API_KEY` or `GEMINI_API_KEY` aren't set, all functions in
`llm_clients.py` automatically simulate realistic responses (with randomised latency,
token counts, and placeholder text clearly labeled `[MOCK ...]`).

```bash
pip install -r requirements.txt
python task1_multi_llm_comparison.py
python task2_prompt_playground.py
python task3_streaming_chat.py
python task4_token_cost_tracker.py
```

This lets you verify the entire pipeline works *before* signing up for any API key.

---

## 🔑 Switching to Real API Responses

1. Get a free Groq key: https://console.groq.com/keys
2. Get a free Gemini key: https://aistudio.google.com/app/apikey
3. Set both as environment variables:

```bash
export GROQ_API_KEY="your_groq_key_here"
export GEMINI_API_KEY="your_gemini_key_here"
```

On Windows (PowerShell):
```powershell
$env:GROQ_API_KEY="your_groq_key_here"
$env:GEMINI_API_KEY="your_gemini_key_here"
```

Once both are set, `MOCK_MODE` automatically turns off and every script makes real
HTTP calls to Groq / Gemini using plain `requests` (no provider SDK required).

---

## Project Structure

```
llm_project/
├── llm_clients.py                    ← Shared API client (Groq + Gemini + mock fallback)
├── task1_multi_llm_comparison.py     ← Task 1: Multi-LLM Response Comparison Tool
├── task2_prompt_playground.py        ← Task 2: Prompt Engineering Playground
├── task3_streaming_chat.py           ← Task 3: Streaming AI Chat Assistant
├── task4_token_cost_tracker.py       ← Task 4: Token Usage and Cost Tracker
├── requirements.txt
├── README.md                         ← This file
├── outputs/
│   ├── task1_llm_comparison.csv / .json
│   ├── task2_prompt_playground.csv / .json
│   ├── task3_chat_transcript.json
│   └── task4_usage_report.json
└── logs/
    └── usage_log.csv                 ← Running log of every tracked API call
```

---

## Task 1 — Multi-LLM Response Comparison Tool

Sends the same prompt to **Groq** and **Gemini**, records:
- Response time (seconds)
- Response length (characters + words)
- Token usage
- Full generated text

Results are saved to both `outputs/task1_llm_comparison.csv` and `.json`, and a
comparison table is printed for each prompt.

```bash
python task1_multi_llm_comparison.py
```

---

## Task 2 — Prompt Engineering Playground

Tests **5 different prompt strategies** for the same use case (news article
summarization):

| # | Strategy | Idea |
|---|---|---|
| 1 | Naive/direct | Minimal instruction, baseline |
| 2 | Role-based | "You are an expert editor..." |
| 3 | Structured/format | Asks for 3 bullet points, word limit |
| 4 | Few-shot | Gives one example before asking |
| 5 | Chain-of-thought | Asks model to reason before summarizing |

Each output is scored with a transparent, reproducible heuristic (ideal word-count
range + structure markers) so the "best prompt" pick isn't a black box. All outputs
and scores are saved to `outputs/task2_prompt_playground.csv` / `.json`.

```bash
python task2_prompt_playground.py
```

> 💡 Swap `SAMPLE_ARTICLE` for a real row from the [BBC News Dataset](https://www.kaggle.com/datasets/cdminix/bbc-news-fulltext-and-category) to test against real news data.

---

## Task 3 — Streaming AI Chat Assistant

A command-line chatbot that:
- Maintains full chat history using `system` / `user` / `assistant` roles
- Streams responses **chunk-by-chunk** as they arrive (visible token-by-token in the terminal)
- Saves the full transcript to `outputs/task3_chat_transcript.json` on exit

```bash
python task3_streaming_chat.py
```

Type your message and watch the response stream in real time. Type `exit` or `quit`
to end the session. If run without an interactive terminal (e.g. in an automated
script), it falls back to a 3-message scripted demo automatically.

---

## Task 4 — Token Usage and Cost Tracker

A reusable `TokenCostTracker` class that wraps any Groq/Gemini call and:
- Logs prompt text, response text, token counts, and estimated cost to `logs/usage_log.csv`
- Generates a final report: total requests, total tokens, total cost, broken down by provider

```bash
python task4_token_cost_tracker.py
```

Cost is estimated using each provider's published pay-as-you-go rate (free-tier usage
costs $0 in practice, but this gives a meaningful "as-if-paid" estimate useful for
budgeting once a project scales past free limits).

```python
# Example: using the tracker inside your own script
from task4_token_cost_tracker import TokenCostTracker

tracker = TokenCostTracker()
tracker.track_groq_call("Summarize this in one sentence: ...")
tracker.print_report()
```

---

## Design Notes

- **No provider SDKs required** — all calls use plain `requests` HTTP calls, so the
  only dependencies are `requests` and `pandas`.
- **Token estimation fallback** — if a provider's response doesn't include exact usage
  data, a ~4-characters-per-token heuristic is used as a documented approximation.
- **Mock Mode is automatic and transparent** — every mock response is clearly prefixed
  with `[MOCK ...]` so there's never ambiguity about whether a real API was called.
- **Optional BBC News Dataset** — Tasks 2 and 4 are structured so you can drop in real
  article text from the [BBC News Dataset](https://www.kaggle.com/datasets/cdminix/bbc-news-fulltext-and-category) in place of the sample article.

---

## Submission Checklist

- ✅ Task 1: Multi-LLM comparison tool with CSV + JSON output and comparison table
- ✅ Task 2: 5 prompt variants tested, scored, and best one identified
- ✅ Task 3: Streaming chatbot with system/user/assistant history
- ✅ Task 4: Token + cost tracker with CSV log and final usage report
- ✅ README with setup instructions
- ✅ Code runs out-of-the-box in Mock Mode (no API key required to verify)
